package com.webrunner.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class LauncherActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST = 1001;
    private static final int FOLDER_PICKER_REQUEST = 1002;
    private static final String HIDDEN_ROOT = ".webrunner";

    private RecyclerView recycler;
    private TextView emptyView;
    private AppAdapter adapter;
    private final List<AppInfo> apps = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);

        recycler = findViewById(R.id.recycler_apps);
        emptyView = findViewById(R.id.empty_view);
        MaterialButton btnCustom = findViewById(R.id.btn_custom_folder);
        findViewById(R.id.btn_reload).setOnClickListener(v -> scanApps());

        recycler.setLayoutManager(new LinearLayoutManager(this));
        adapter = new AppAdapter();
        recycler.setAdapter(adapter);

        btnCustom.setOnClickListener(v -> openFolderPicker());

        requestPermissionsIfNeeded();
        scanApps();
    }

    private void requestPermissionsIfNeeded() {
        List<String> needed = new ArrayList<>();
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.RECORD_AUDIO);
        }
        if (Build.VERSION.SDK_INT <= 32 &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (!needed.isEmpty()) {
            ActivityCompat.requestPermissions(this, needed.toArray(new String[0]), PERMISSION_REQUEST);
        }
    }

    private void scanApps() {
        apps.clear();
        File root = new File(Environment.getExternalStorageDirectory(), HIDDEN_ROOT);

        if (!root.exists()) {
            root.mkdirs();
        }

        File[] folders = root.listFiles(File::isDirectory);
        if (folders != null) {
            for (File folder : folders) {
                File index = new File(folder, "index.html");
                if (index.exists()) {
                    AppInfo info = new AppInfo();
                    info.name = folder.getName();
                    info.folderPath = folder.getAbsolutePath();
                    info.indexPath = index.getAbsolutePath();

                    // Optional icon
                    File icon = new File(folder, "icon.png");
                    if (!icon.exists()) icon = new File(folder, "icon.jpg");
                    if (icon.exists()) info.iconPath = icon.getAbsolutePath();

                    // Optional description
                    File infoFile = new File(folder, "info.txt");
                    if (infoFile.exists()) {
                        try (BufferedReader br = new BufferedReader(new FileReader(infoFile))) {
                            StringBuilder sb = new StringBuilder();
                            String line;
                            while ((line = br.readLine()) != null) {
                                sb.append(line).append(" ");
                            }
                            info.description = sb.toString().trim();
                        } catch (Exception ignored) {}
                    }
                    if (info.description == null || info.description.isEmpty()) {
                        info.description = "Tap to open";
                    }
                    apps.add(info);
                }
            }
        }

        adapter.notifyDataSetChanged();
        emptyView.setVisibility(apps.isEmpty() ? View.VISIBLE : View.GONE);
        recycler.setVisibility(apps.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private void openFolderPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(intent, FOLDER_PICKER_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FOLDER_PICKER_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri treeUri = data.getData();
            if (treeUri != null) {
                getContentResolver().takePersistableUriPermission(treeUri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);

                DocumentFile dir = DocumentFile.fromTreeUri(this, treeUri);
                if (dir != null) {
                    DocumentFile index = dir.findFile("index.html");
                    if (index != null && index.exists()) {
                        // Launch with content URI
                        Intent i = new Intent(this, MainActivity.class);
                        i.putExtra("folder_uri", treeUri.toString());
                        i.putExtra("is_saf", true);
                        startActivity(i);
                    } else {
                        Toast.makeText(this, "No index.html found in selected folder", Toast.LENGTH_LONG).show();
                    }
                }
            }
        }
    }

    private void launchApp(AppInfo info) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("index_path", info.indexPath);
        i.putExtra("folder_path", info.folderPath);
        i.putExtra("is_saf", false);
        startActivity(i);
    }

    // ─── data class ───
    static class AppInfo {
        String name;
        String description;
        String folderPath;
        String indexPath;
        String iconPath;
    }

    // ─── adapter ───
    class AppAdapter extends RecyclerView.Adapter<AppAdapter.VH> {
        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_app, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            AppInfo a = apps.get(position);
            h.name.setText(a.name);
            h.desc.setText(a.description);
            if (a.iconPath != null) {
                h.icon.setImageBitmap(BitmapFactory.decodeFile(a.iconPath));
            } else {
                h.icon.setImageResource(android.R.drawable.ic_menu_gallery);
            }
            h.itemView.setOnClickListener(v -> launchApp(a));
        }

        @Override
        public int getItemCount() {
            return apps.size();
        }

        class VH extends RecyclerView.ViewHolder {
            ImageView icon;
            TextView name, desc;
            VH(View v) {
                super(v);
                icon = v.findViewById(R.id.app_icon);
                name = v.findViewById(R.id.app_name);
                desc = v.findViewById(R.id.app_desc);
            }
        }
    }
}
