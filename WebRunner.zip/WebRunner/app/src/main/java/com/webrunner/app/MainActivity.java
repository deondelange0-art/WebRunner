package com.webrunner.app;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.documentfile.provider.DocumentFile;

import org.json.JSONArray;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "WebRunner";

    private WebView webView;
    private TextToSpeech tts;
    private SpeechRecognizer speechRecognizer;
    private boolean isListening = false;
    private File dataDir;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        dataDir = new File(getFilesDir(), "js_data");
        if (!dataDir.exists()) dataDir.mkdirs();

        initTextToSpeech();
        initSpeechRecognizer();
        setupWebView();

        // Decide what to load
        boolean isSaf = getIntent().getBooleanExtra("is_saf", false);
        if (isSaf) {
            String uriStr = getIntent().getStringExtra("folder_uri");
            if (uriStr != null) {
                loadFromSaf(Uri.parse(uriStr));
            }
        } else {
            String indexPath = getIntent().getStringExtra("index_path");
            if (indexPath != null) {
                webView.loadUrl("file://" + indexPath);
            } else {
                Toast.makeText(this, "No app to load", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    private void loadFromSaf(Uri treeUri) {
        DocumentFile dir = DocumentFile.fromTreeUri(this, treeUri);
        if (dir == null) {
            Toast.makeText(this, "Cannot access folder", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        DocumentFile index = dir.findFile("index.html");
        if (index == null || !index.exists()) {
            Toast.makeText(this, "index.html not found", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        // For SAF we load via content:// URI
        webView.loadUrl(index.getUri().toString());
    }

    private void initTextToSpeech() {
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(Locale.getDefault());
            }
        });
    }

    private void initSpeechRecognizer() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return;

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {}
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {}
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}

            @Override
            public void onError(int error) {
                isListening = false;
                final String msg = "Speech error: " + error;
                runOnUiThread(() -> webView.evaluateJavascript(
                        "window.onSpeechError && window.onSpeechError('" + msg + "');", null));
            }

            @Override
            public void onResults(Bundle results) {
                isListening = false;
                ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String spoken = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                String safe = spoken.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ");
                runOnUiThread(() -> webView.evaluateJavascript(
                        "window.onSpeechResult && window.onSpeechResult('" + safe + "');", null));
            }
        });
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        request.grant(request.getResources());
                    }
                });
            }
        });
    }

    // ─────────────────────────────────────────────
    //  JavaScript Bridge
    // ─────────────────────────────────────────────
    public class AndroidBridge {

        @JavascriptInterface
        public void speak(String text) {
            if (tts != null) {
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "utt");
            }
        }

        @JavascriptInterface
        public void stopSpeaking() {
            if (tts != null) tts.stop();
        }

        @JavascriptInterface
        public void startListening() {
            runOnUiThread(() -> {
                if (speechRecognizer == null) {
                    webView.evaluateJavascript(
                            "window.onSpeechError && window.onSpeechError('Not available');", null);
                    return;
                }
                if (isListening) return;

                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);

                isListening = true;
                speechRecognizer.startListening(intent);
            });
        }

        @JavascriptInterface
        public void stopListening() {
            runOnUiThread(() -> {
                if (speechRecognizer != null && isListening) {
                    speechRecognizer.stopListening();
                    isListening = false;
                }
            });
        }

        @JavascriptInterface
        public boolean saveFile(String filename, String data) {
            try {
                if (filename.contains("..") || filename.contains("/") || filename.contains("\\"))
                    return false;
                File file = new File(dataDir, filename);
                try (FileOutputStream fos = new FileOutputStream(file)) {
                    fos.write(data.getBytes(StandardCharsets.UTF_8));
                }
                return true;
            } catch (Exception e) {
                Log.e(TAG, "saveFile", e);
                return false;
            }
        }

        @JavascriptInterface
        public String loadFile(String filename) {
            try {
                if (filename.contains("..") || filename.contains("/") || filename.contains("\\"))
                    return null;
                File file = new File(dataDir, filename);
                if (!file.exists()) return null;

                StringBuilder sb = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line).append("\n");
                    }
                }
                return sb.toString().trim();
            } catch (Exception e) {
                Log.e(TAG, "loadFile", e);
                return null;
            }
        }

        @JavascriptInterface
        public boolean deleteFile(String filename) {
            try {
                if (filename.contains("..") || filename.contains("/") || filename.contains("\\"))
                    return false;
                File file = new File(dataDir, filename);
                return file.exists() && file.delete();
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public String listFiles() {
            try {
                File[] files = dataDir.listFiles();
                JSONArray arr = new JSONArray();
                if (files != null) {
                    for (File f : files) {
                        if (f.isFile()) arr.put(f.getName());
                    }
                }
                return arr.toString();
            } catch (Exception e) {
                return "[]";
            }
        }

        @JavascriptInterface
        public String getDataPath() {
            return dataDir.getAbsolutePath();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        if (speechRecognizer != null) {
            speechRecognizer.destroy();
        }
        super.onDestroy();
    }
}
