# Keep the JavascriptInterface methods
-keepclassmembers class com.webrunner.app.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
