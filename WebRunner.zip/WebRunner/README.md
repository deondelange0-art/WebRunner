# Web Runner

A lightweight Android launcher + WebView shell.

One installed APK can run many small HTML/CSS/JS apps.

## Features

- **Multi-app launcher** – scans `/.webrunner/` for apps
- Each app folder can contain:
  - `index.html` (required)
  - `icon.png` or `icon.jpg` (optional)
  - `info.txt` (optional short description)
- **Custom folder picker** – open any folder that has an `index.html`
- **Native JavaScript bridge**
  - `Android.speak(text)` – Text-to-Speech
  - `Android.startListening()` / `stopListening()` – Microphone
  - `Android.saveFile(name, data)` / `loadFile(name)` / `deleteFile(name)` / `listFiles()`
- Works on **Android 7.0 (API 24)** and newer
- Modern WebView with microphone, camera & media support

## How to build the APK (easiest way)

1. Create a new GitHub repository
2. Upload **all** the files from this project (or push via git)
3. Go to the **Actions** tab → select **Build APK** → **Run workflow**
4. When it finishes, download the APK from the **Artifacts** section

You can also trigger the build automatically on every push to `main`.

## How to use after installing

1. Open a file manager on your phone
2. Create the folder: `/storage/emulated/0/.webrunner/`
3. Inside it create one folder per app, e.g.:
   ```
   .webrunner/
   ├── MyNotes/
   │   ├── index.html
   │   ├── icon.png
   │   └── info.txt
   └── Calculator/
       ├── index.html
       └── info.txt
   ```
4. Open **Web Runner** – your apps appear in the list
5. Tap an app to run it

### JavaScript bridge example

```html
<script>
  // Text-to-Speech
  Android.speak("Hello from native TTS");

  // Microphone
  Android.startListening();
  window.onSpeechResult = function(text) {
    console.log("Heard:", text);
  };
  window.onSpeechError = function(err) {
    console.error(err);
  };

  // Save / Load data
  Android.saveFile("settings.json", JSON.stringify({theme: "dark"}));
  const data = Android.loadFile("settings.json");
</script>
```

## Requirements

- minSdk 24 (Android 7.0)
- targetSdk 34
- Permissions: Internet, Microphone, Storage (for older Android)
